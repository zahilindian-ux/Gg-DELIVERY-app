import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.lovable.ggdelivery',
  appName: 'GG Delivery',
  webDir: 'dist/client',
  server: {
    androidScheme: 'https',
  },
};

export default config;
