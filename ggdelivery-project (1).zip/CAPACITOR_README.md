# Capacitor Android Build

This project is configured to build an Android APK via [Capacitor](https://capacitorjs.com/) and [Codemagic](https://codemagic.io/).

## Files

- `capacitor.config.ts` — Capacitor config (appId: `app.lovable.ggdelivery`, webDir: `dist/client`).
- `codemagic.yaml` — Codemagic CI pipeline that installs deps, builds the Vite web app, adds the Android platform, and produces a debug APK.

## Local build

```bash
npm install
npm install -D @capacitor/cli
npm install @capacitor/core @capacitor/android
npm run build
npx cap add android      # first time only
npx cap sync android
cd android && ./gradlew assembleDebug
```

Output: `android/app/build/outputs/apk/debug/app-debug.apk`

Requires: Node 20+, JDK 17, Android SDK (Android Studio).

## Codemagic build

1. Push this repo to GitHub/GitLab/Bitbucket.
2. Connect it in Codemagic (https://codemagic.io/).
3. Codemagic auto-detects `codemagic.yaml` and runs the `android-debug` workflow.
4. Download `app-debug.apk` from the build artifacts.

> Note: APKs cannot be built inside the Lovable sandbox — there is no Android SDK/JDK/Gradle here. Use Codemagic (or local Android Studio) to produce the `.apk`.
