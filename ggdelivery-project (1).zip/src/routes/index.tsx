import { createFileRoute } from "@tanstack/react-router";
import { ClientOnly } from "@tanstack/react-router";
import GgApp from "@/components/GgApp.jsx";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "GG Grocery — Fast delivery" },
      { name: "description", content: "Order groceries and daily essentials with fast delivery." },
      { property: "og:title", content: "GG Grocery — Fast delivery" },
      { property: "og:description", content: "Order groceries and daily essentials with fast delivery." },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <ClientOnly fallback={<div style={{ minHeight: "100vh" }} />}>
      <GgApp />
    </ClientOnly>
  );
}
