import React, { useState, useEffect } from 'react';
import { 
  Home, ShoppingCart, User, Search, Plus, Minus, 
  Package, MapPin, CheckCircle, Box, LayoutDashboard, LogOut, ShieldCheck, PlusCircle, Trash2, Bell, MessageSquare, Edit3
} from 'lucide-react';

const DELIVERY_CHARGE = 10;

const SEED_CATEGORIES = [
  "All", "Fruits & Veggies", "Dairy & Bread", "Munchies & Snacks", 
  "Cold Drinks & Juices", "Instant & Frozen", "Tea, Coffee & Health", 
  "Bakery & Biscuits", "Sweet Cravings", "Atta, Rice & Dal", 
  "Masala & Oil", "Cleaning Essentials", "Personal Care", "Baby & Pet Care"
];

const INITIAL_CATALOG = [
  { id: 'b1', name: "Fresh Shimla Apple", category: "Fruits & Veggies", brand: "Fresh", price: 160, discountPrice: 139, weightOrSize: "4 pcs (approx 500g)", stock: 100, image: "🍎", imageUrl: "https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=400" },
  { id: 'b2', name: "Robusta Banana", category: "Fruits & Veggies", brand: "Farm Fresh", price: 60, discountPrice: 48, weightOrSize: "1 pack (6 pcs)", stock: 120, image: "🍌", imageUrl: "https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=400" },
  { id: 'b3', name: "Desi Tomato", category: "Fruits & Veggies", brand: "Farm Fresh", price: 40, discountPrice: 32, weightOrSize: "500 g", stock: 150, image: "🍅", imageUrl: "https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=400" },
  { id: 'b7', name: "Amul Taaza Fresh Milk", category: "Dairy & Bread", brand: "Amul", price: 34, discountPrice: 32, weightOrSize: "500 ml", stock: 200, image: "🥛", imageUrl: "https://images.unsplash.com/photo-1550583724-b2692b85b150?w=400" },
  { id: 'b12', name: "Lay's Magic Masala Chips", category: "Munchies & Snacks", brand: "Lay's", price: 20, discountPrice: 20, weightOrSize: "50 g", stock: 250, image: "🥔", imageUrl: "https://images.unsplash.com/photo-1566478989037-eec170784d0b?w=400" },
  { id: 'b16', name: "Coca-Cola Cold Drink", category: "Cold Drinks & Juices", brand: "Coca Cola", price: 90, discountPrice: 82, weightOrSize: "750 ml", stock: 150, image: "🥤", imageUrl: "https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=400" },
  { id: 'b21', name: "Maggi 2-Minute Noodles", category: "Instant & Frozen", brand: "Nestle", price: 14, discountPrice: 14, weightOrSize: "70 g", stock: 400, image: "🍜", imageUrl: "https://images.unsplash.com/photo-1612927601601-66384047381a?w=400" },
];

export default function App() {
  const [user, setUser] = useState(null);
  const [isAdminMode, setIsAdminMode] = useState(false);
  const [toast, setToast] = useState(null);

  const [products, setProducts] = useState(() => {
    const saved = localStorage.getItem('gg_products_sahil');
    return saved ? JSON.parse(saved) : INITIAL_CATALOG;
  });

  const [orders, setOrders] = useState(() => {
    const saved = localStorage.getItem('gg_orders_sahil');
    return saved ? JSON.parse(saved) : [];
  });

  const [userProfiles, setUserProfiles] = useState(() => {
    const saved = localStorage.getItem('gg_profiles_sahil');
    return saved ? JSON.parse(saved) : {};
  });

  const [cart, setCart] = useState([]);
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    localStorage.setItem('gg_products_sahil', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('gg_orders_sahil', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('gg_profiles_sahil', JSON.stringify(userProfiles));
  }, [userProfiles]);

  const showToast = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const addNotification = (title, message) => {
    const newNotif = { id: 'notif_' + Date.now(), title, message, time: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) };
    setNotifications(prev => [newNotif, ...prev]);
    showToast(`🔔 ${title}`);
  };

  if (!user) {
    return <LoginScreen setUser={setUser} setIsAdminMode={setIsAdminMode} showToast={showToast} setUserProfiles={setUserProfiles} userProfiles={userProfiles} />;
  }

  const currentUserProfile = userProfiles[user.uid] || { name: 'Sahil', phone: '9876543210', address: 'Main Market, Girajsar' };

  if (!currentUserProfile.isComplete && !isAdminMode) {
    return <DetailedSignUpScreen user={user} userProfiles={userProfiles} setUserProfiles={setUserProfiles} showToast={showToast} addNotification={addNotification} />;
  }

  return (
    <div className="flex justify-center bg-gray-900 min-h-screen text-gray-800 font-sans">
      <div className="w-full max-w-md bg-gray-50 h-screen overflow-hidden flex flex-col relative shadow-2xl md:rounded-[2.5rem] md:my-4 md:h-[95vh] md:border-[8px] md:border-gray-800">
        
        <div className="bg-green-600 text-white text-xs px-4 py-1.5 flex justify-between items-center z-50">
          <span className="font-bold">GG DELIVERY (Girajsar) - {isAdminMode ? 'Admin' : currentUserProfile.name}</span>
          <span>{new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
        </div>

        {isAdminMode ? (
          <AdminPanel 
            products={products} 
            setProducts={setProducts}
            orders={orders} 
            setOrders={setOrders}
            showToast={showToast}
            addNotification={addNotification}
            onLogout={() => { setIsAdminMode(false); setUser(null); }}
          />
        ) : (
          <CustomerApp 
            products={products} 
            orders={orders.filter(o => o.customerId === user.uid)} 
            cart={cart}
            setCart={setCart}
            userProfile={currentUserProfile}
            setUserProfile={(updated) => setUserProfiles(prev => ({ ...prev, [user.uid]: updated }))}
            showToast={showToast}
            user={user}
            setOrders={setOrders}
            notifications={notifications}
            addNotification={addNotification}
            onLogout={() => { setUser(null); }}
          />
        )}

        {toast && (
          <div className="absolute top-12 left-1/2 transform -translate-x-1/2 z-50 bg-gray-900 text-white px-4 py-2 rounded-full shadow-lg text-xs flex items-center gap-2 animate-bounce">
            <CheckCircle size={16} className="text-green-400" />
            {toast}
          </div>
        )}
      </div>
    </div>
  );
}

// ================= DETAILED SIGN UP SCREEN =================
function DetailedSignUpScreen({ user, userProfiles, setUserProfiles, showToast, addNotification }) {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    address: '',
    landmark: '',
    pincode: '334001'
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.phone || !formData.address) {
      showToast("Please fill all required fields!");
      return;
    }

    const fullProfile = {
      name: formData.name.trim(),
      email: user.username || 'customer@ggdelivery.com',
      phone: formData.phone.trim(),
      address: `${formData.address.trim()}, Landmark: ${formData.landmark.trim() || 'N/A'}, Pincode: ${formData.pincode.trim()}`,
      pincode: formData.pincode.trim(),
      isComplete: true
    };

    setUserProfiles(prev => ({ ...prev, [user.uid]: fullProfile }));
    addNotification("Account Created!", "Welcome to GG Delivery, Girajsar! Account registered successfully.");
    showToast("Profile Registered Successfully! 🎉");
  };

  return (
    <div className="flex h-screen items-center justify-center bg-green-50 p-6">
      <div className="w-full max-w-md bg-white p-6 rounded-3xl shadow-xl space-y-4 overflow-y-auto max-h-[90vh]">
        <div className="text-center">
          <div className="w-16 h-16 bg-green-600 rounded-2xl mx-auto flex items-center justify-center shadow-lg shadow-green-200 mb-2">
            <Package size={32} color="white" />
          </div>
          <h2 className="text-xl font-black text-gray-800">Complete Your Signup</h2>
          <p className="text-xs text-gray-500">Girajsar delivery profile setup by Sahil</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3 pt-2">
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-gray-600">Full Name *</label>
            <input 
              type="text" 
              placeholder="e.g. Sahil" 
              value={formData.name} 
              onChange={e => setFormData({...formData, name: e.target.value})} 
              className="w-full bg-gray-50 border border-gray-200 rounded-xl p-2.5 text-xs outline-none focus:border-green-500"
              required 
            />
          </div>

          <div className="space-y-1">
            <label className="text-[11px] font-bold text-gray-600">Phone Number *</label>
            <input 
              type="tel" 
              placeholder="10-digit mobile number" 
              value={formData.phone} 
              onChange={e => setFormData({...formData, phone: e.target.value})} 
              className="w-full bg-gray-50 border border-gray-200 rounded-xl p-2.5 text-xs outline-none focus:border-green-500"
              required 
            />
          </div>

          <div className="space-y-1">
            <label className="text-[11px] font-bold text-gray-600">Full Address *</label>
            <textarea 
              placeholder="House No, Street, Area in Girajsar" 
              value={formData.address} 
              onChange={e => setFormData({...formData, address: e.target.value})} 
              className="w-full bg-gray-50 border border-gray-200 rounded-xl p-2.5 text-xs outline-none focus:border-green-500 h-16"
              required 
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-gray-600">Landmark</label>
              <input 
                type="text" 
                placeholder="e.g. Near Temple" 
                value={formData.landmark} 
                onChange={e => setFormData({...formData, landmark: e.target.value})} 
                className="w-full bg-gray-50 border border-gray-200 rounded-xl p-2.5 text-xs outline-none focus:border-green-500" 
              />
            </div>
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-gray-600">Pincode</label>
              <input 
                type="text" 
                placeholder="334001" 
                value={formData.pincode} 
                onChange={e => setFormData({...formData, pincode: e.target.value})} 
                className="w-full bg-gray-50 border border-gray-200 rounded-xl p-2.5 text-xs outline-none focus:border-green-500" 
              />
            </div>
          </div>

          <button 
            type="submit" 
            className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 rounded-xl text-xs shadow-lg shadow-green-200 mt-2 active:scale-95 transition-all"
          >
            Save Profile & Start Shopping
          </button>
        </form>
      </div>
    </div>
  );
}

// ================= LOGIN SCREEN =================
function LoginScreen({ setUser, setIsAdminMode, showToast, setUserProfiles, userProfiles }) {
  const [isAdminTab, setIsAdminTab] = useState(false);
  const [isRegisterMode, setIsRegisterMode] = useState(false);
  const [usernameInput, setUsernameInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [adminEmail, setAdminEmail] = useState('admin@ggdelivery.com');

  const handleCustomerAuth = (e) => {
    e.preventDefault();
    const uname = usernameInput.trim().toLowerCase();
    const pwd = passwordInput.trim();

    if (!uname || !pwd) {
      showToast("Please enter username and password!");
      return;
    }

    const userId = 'user_' + uname;

    if (isRegisterMode) {
      if (pwd.length < 6) {
        showToast("Password must be at least 6 characters!");
        return;
      }
      if (userProfiles[userId] && userProfiles[userId].password === pwd) {
        showToast("Username already exists! Please login.");
        return;
      }
      // Register new user
      setUserProfiles(prev => ({
        ...prev,
        [userId]: { ...(prev[userId] || {}), password: pwd, isComplete: prev[userId]?.isComplete || false }
      }));
      setUser({ uid: userId, username: uname });
      showToast("Account Created Successfully! 🎉");
    } else {
      // Login check
      const existing = userProfiles[userId];
      if (existing && existing.password === pwd) {
        setUser({ uid: userId, username: uname });
        showToast("Login Successful! 🎉");
      } else {
        // If profile doesn't exist in local state yet, let them in to set up profile
        setUser({ uid: userId, username: uname });
        showToast("Welcome! Please complete your profile.");
      }
    }
  };

  const handleAdminLogin = (e) => {
    e.preventDefault();
    if (adminPassword === "123S123S") {
      setUser({ uid: 'admin_sahil', email: adminEmail });
      setIsAdminMode(true);
      showToast("Admin Logged In Successfully!");
    } else {
      showToast("Incorrect Admin Password! Use 123S123S");
    }
  };

  return (
    <div className="flex h-screen items-center justify-center bg-green-50 p-6">
      <div className="w-full max-w-sm bg-white p-8 rounded-3xl shadow-xl text-center space-y-6">
        <div className="w-20 h-20 bg-green-600 rounded-2xl mx-auto flex items-center justify-center shadow-lg shadow-green-200">
          <Package size={40} color="white" />
        </div>
        <div>
          <h1 className="text-2xl font-black text-gray-800 tracking-tight">GG DELIVERY</h1>
          <p className="text-gray-500 text-sm mt-1">Girajsar Quick Commerce</p>
        </div>

        <div className="flex bg-gray-100 p-1 rounded-xl">
          <button 
            onClick={() => { setIsAdminTab(false); setIsRegisterMode(false); }}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${!isAdminTab ? 'bg-white text-green-700 shadow-sm' : 'text-gray-500'}`}
          >
            Customer Portal
          </button>
          <button 
            onClick={() => setIsAdminTab(true)}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${isAdminTab ? 'bg-white text-green-700 shadow-sm' : 'text-gray-500'}`}
          >
            Admin Panel
          </button>
        </div>

        {!isAdminTab ? (
          <form onSubmit={handleCustomerAuth} className="space-y-3.5 pt-1">
            <div className="flex justify-between items-center mb-1">
              <span className="text-xs font-bold text-gray-700">{isRegisterMode ? 'New Customer Signup' : 'Customer Login'}</span>
              <button 
                type="button" 
                onClick={() => setIsRegisterMode(!isRegisterMode)} 
                className="text-[11px] text-green-600 font-bold underline"
              >
                {isRegisterMode ? 'Existing User? Login' : 'New User? Register'}
              </button>
            </div>

            <input 
              type="text" 
              placeholder="Username / Mobile No" 
              value={usernameInput} 
              onChange={e => setUsernameInput(e.target.value)}
              className="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-xs outline-none focus:border-green-500"
              required 
            />

            <input 
              type="password" 
              placeholder="Secure Password (min 6 chars)" 
              value={passwordInput} 
              onChange={e => setPasswordInput(e.target.value)}
              className="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-xs outline-none focus:border-green-500"
              required 
            />

            <button type="submit" className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 rounded-xl text-xs shadow-md active:scale-95 transition-all">
              {isRegisterMode ? 'Sign Up & Continue' : 'Login to Account'}
            </button>
          </form>
        ) : (
          <form onSubmit={handleAdminLogin} className="space-y-4 pt-1">
            <div className="text-left space-y-1">
              <label className="text-xs font-bold text-gray-600">Admin Email</label>
              <input 
                type="email" 
                value={adminEmail} 
                onChange={(e) => setAdminEmail(e.target.value)} 
                className="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-sm outline-none focus:border-green-500"
                required 
              />
            </div>
            <div className="text-left space-y-1">
              <label className="text-xs font-bold text-gray-600">Admin Password</label>
              <input 
                type="password" 
                value={adminPassword} 
                onChange={e => setAdminPassword(e.target.value)} 
                placeholder="Enter password..." 
                className="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-sm outline-none focus:border-green-500"
                required 
              />
            </div>
            <button 
              type="submit"
              className="w-full bg-gray-900 hover:bg-black text-white font-bold py-3 px-4 rounded-xl flex items-center justify-center gap-2 shadow-lg text-xs"
            >
              <ShieldCheck size={16} /> Login as Admin
            </button>
          </form>
        )}
      </div>
    </div>
  );
}

// ================= CUSTOMER APP =================
function CustomerApp({ products, orders, cart, setCart, userProfile, setUserProfile, showToast, user, setOrders, notifications, addNotification, onLogout }) {
  const [activeTab, setActiveTab] = useState('home');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  const addToCart = (product) => {
    if ((product.stock || 0) <= 0) {
      showToast("Product is Out of Stock!");
      return;
    }
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item => item.product.id === product.id ? { ...item, qty: item.qty + 1 } : item);
      }
      return [...prev, { product, qty: 1 }];
    });
    showToast("Added to Cart 🛒");
  };

  const updateCartQty = (productId, delta) => {
    setCart(prev => prev.map(item => {
      if (item.product.id === productId) {
        const newQty = item.qty + delta;
        return newQty > 0 ? { ...item, qty: newQty } : null;
      }
      return item;
    }).filter(Boolean));
  };

  const filteredProducts = products.filter(p => {
    const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          (p.brand && p.brand.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="flex flex-col h-full bg-gray-50 relative">
      <div className="flex-1 overflow-y-auto pb-20">
        {activeTab === 'home' && (
          <CustomerHome 
            products={filteredProducts} 
            searchQuery={searchQuery} 
            setSearchQuery={setSearchQuery}
            selectedCategory={selectedCategory}
            setSelectedCategory={setSelectedCategory}
            addToCart={addToCart}
            userProfile={userProfile}
            addNotification={addNotification}
          />
        )}
        {activeTab === 'cart' && (
          <CartScreen cart={cart} updateCartQty={updateCartQty} userProfile={userProfile} setUserProfile={setUserProfile} user={user} showToast={showToast} setOrders={setOrders} addNotification={addNotification} onOrderPlaced={() => {setCart([]); setActiveTab('orders');}} />
        )}
        {activeTab === 'orders' && <OrderHistory orders={orders} />}
        {activeTab === 'notifications' && <NotificationScreen notifications={notifications} />}
        {activeTab === 'profile' && <ProfileScreen userProfile={userProfile} user={user} showToast={showToast} onLogout={onLogout} />}
      </div>

      <div className="absolute bottom-0 w-full bg-white border-t border-gray-200 px-4 py-2.5 flex justify-between items-center z-40 pb-6 md:pb-3 shadow-lg">
        <NavButton icon={<Home />} label="Home" active={activeTab === 'home'} onClick={() => setActiveTab('home')} />
        <NavButton icon={<Box />} label="Orders" active={activeTab === 'orders'} onClick={() => setActiveTab('orders')} />
        <div className="relative">
          <NavButton icon={<ShoppingCart />} label="Cart" active={activeTab === 'cart'} onClick={() => setActiveTab('cart')} />
          {cart.length > 0 && (
            <span className="absolute -top-1 right-1 bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full border-2 border-white">
              {cart.reduce((sum, item) => sum + item.qty, 0)}
            </span>
          )}
        </div>
        <NavButton icon={<Bell />} label="Alerts" active={activeTab === 'notifications'} onClick={() => setActiveTab('notifications')} />
        <NavButton icon={<User />} label="Profile" active={activeTab === 'profile'} onClick={() => setActiveTab('profile')} />
      </div>
    </div>
  );
}

function NavButton({ icon, label, active, onClick }) {
  return (
    <button onClick={onClick} className={`flex flex-col items-center justify-center w-14 gap-0.5 transition-colors ${active ? 'text-green-600 font-bold' : 'text-gray-400 hover:text-gray-600'}`}>
      {React.cloneElement(icon, { size: 20, strokeWidth: active ? 2.5 : 2 })}
      <span className="text-[10px]">{label}</span>
    </button>
  );
}

function CustomerHome({ products, searchQuery, setSearchQuery, selectedCategory, setSelectedCategory, addToCart, userProfile, addNotification }) {
  const triggerDailyReminderMock = () => {
    addNotification("Daily Reminder 🌅", "Subah ki shuruaat fresh groceries ke sath! Doodh, sabzi, aur fruits par special discounts available hain.");
  };

  return (
    <div className="p-4 space-y-5">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-black text-gray-800">Hello, {userProfile?.name || 'Customer'} 👋</h2>
          <p className="text-xs text-gray-500">Superfast Delivery in Girajsar</p>
        </div>
        <button onClick={triggerDailyReminderMock} className="w-9 h-9 bg-green-100 text-green-700 rounded-xl flex items-center justify-center shadow-inner text-xs font-black">
          🌅
        </button>
      </div>

      <div className="relative">
        <Search className="absolute left-3.5 top-3.5 text-gray-400" size={18} />
        <input 
          type="text" 
          placeholder="Search 'milk', 'chips', 'atta'..." 
          className="w-full bg-white border border-gray-200 rounded-2xl py-3 pl-11 pr-4 shadow-sm focus:ring-2 focus:ring-green-500 outline-none text-sm"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <div className="w-full bg-gradient-to-r from-green-600 to-green-500 rounded-2xl p-4 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10">
          <span className="bg-white/20 px-2.5 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider">Girajsar Special</span>
          <h3 className="text-xl font-black mt-1">FLAT ₹10 DELIVERY</h3>
          <p className="text-xs opacity-90 mt-0.5">Order fresh groceries & snacks instantly</p>
        </div>
      </div>

      <div>
        <h3 className="font-bold text-gray-800 mb-2.5 text-xs">Categories</h3>
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
          {SEED_CATEGORIES.map(cat => (
            <button 
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap shadow-sm transition-all ${selectedCategory === cat ? 'bg-green-600 text-white shadow-green-200' : 'bg-white text-gray-600 border border-gray-100'}`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div>
        <h3 className="font-bold text-gray-800 mb-2.5 text-xs">All Products ({products.length})</h3>
        <div className="grid grid-cols-2 gap-3">
          {products.map(product => {
            const isOutOfStock = (product.stock || 0) <= 0;
            return (
              <div key={product.id} className={`bg-white rounded-2xl p-3 shadow-sm border border-gray-100 flex flex-col justify-between ${isOutOfStock ? 'opacity-60' : ''}`}>
                <div>
                  <div className="h-28 bg-gray-50 rounded-xl mb-2 flex items-center justify-center text-4xl overflow-hidden relative">
                    {product.imageUrl ? (
                      <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover" onError={(e)=>{e.target.style.display='none'}} />
                    ) : (
                      <span>{product.image || '📦'}</span>
                    )}
                    {isOutOfStock && (
                      <span className="absolute bg-red-600 text-white text-[9px] font-bold px-2 py-0.5 rounded-full uppercase">Out of Stock</span>
                    )}
                  </div>
                  <p className="text-[10px] text-gray-400 font-bold uppercase">{product.brand}</p>
                  <h4 className="font-bold text-gray-800 text-xs line-clamp-1 mt-0.5">{product.name}</h4>
                  <p className="text-[11px] text-gray-500 mt-0.5">{product.weightOrSize}</p>
                </div>
                <div className="mt-3 flex items-center justify-between pt-2 border-t border-gray-50">
                  <div>
                    <p className="font-extrabold text-green-600 text-xs">₹{product.discountPrice || product.price}</p>
                    {product.discountPrice && <p className="text-[10px] text-gray-400 line-through">₹{product.price}</p>}
                  </div>
                  <button 
                    disabled={isOutOfStock}
                    onClick={() => addToCart(product)}
                    className={`p-2 rounded-xl active:scale-90 transition-transform ${isOutOfStock ? 'bg-gray-300 text-gray-500 cursor-not-allowed' : 'bg-green-600 hover:bg-green-700 text-white shadow-md'}`}
                  >
                    <Plus size={16} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function CartScreen({ cart, updateCartQty, userProfile, setUserProfile, user, showToast, setOrders, addNotification, onOrderPlaced }) {
  const itemTotal = cart.reduce((sum, item) => sum + ((item.product.discountPrice || item.product.price) * item.qty), 0);
  const totalAmount = itemTotal > 0 ? itemTotal + DELIVERY_CHARGE : 0;
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [isChangingAddress, setIsChangingAddress] = useState(false);
  const [newAddressInput, setNewAddressInput] = useState(userProfile?.address || '');

  const handleUpdateAddress = (e) => {
    e.preventDefault();
    if (!newAddressInput.trim()) {
      showToast("Address cannot be empty!");
      return;
    }
    const updatedProfile = { ...userProfile, address: newAddressInput.trim() };
    setUserProfile(updatedProfile);
    setIsChangingAddress(false);
    showToast("Address Updated Successfully!");
  };

  const placeOrder = () => {
    if (!userProfile?.name || !userProfile?.phone || !userProfile?.address) {
      showToast("Please update your profile & address first!");
      return;
    }
    setIsCheckingOut(true);
    const orderIdCode = 'GG' + Math.floor(1000 + Math.random() * 9000);
    const newOrderObj = {
      id: orderIdCode,
      customerId: user.uid,
      customerName: userProfile.name,
      mobileNumber: userProfile.phone,
      address: userProfile.address,
      items: cart,
      itemTotal,
      deliveryCharge: DELIVERY_CHARGE,
      totalAmount,
      paymentMethod: "Cash on Delivery (COD)",
      status: "Pending",
      createdAt: { seconds: Math.floor(Date.now() / 1000) }
    };

    setOrders(prev => [newOrderObj, ...prev]);
    addNotification("Order Confirmed! 🎉", `Aapka order #${orderIdCode} successfully place ho gaya hai. Total: ₹${totalAmount} (COD).`);
    showToast("Order Placed Successfully! 🎉");
    setIsCheckingOut(false);
    onOrderPlaced();
  };

  if (cart.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center p-6 space-y-3">
        <ShoppingCart size={54} className="text-gray-300" />
        <h2 className="text-lg font-bold text-gray-700">Your Cart is Empty</h2>
        <p className="text-xs text-gray-400">Add fresh groceries and essentials to get started.</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-gray-50">
      <div className="p-4 bg-white shadow-sm flex items-center justify-between">
        <h2 className="font-bold text-gray-800 text-sm">My Shopping Cart</h2>
        <span className="bg-green-100 text-green-700 text-xs font-bold px-2 py-0.5 rounded-full">{cart.length} Items</span>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {cart.map((item, idx) => (
          <div key={idx} className="bg-white p-3 rounded-2xl shadow-sm flex items-center gap-3 border border-gray-100">
            <div className="w-12 h-12 bg-gray-50 rounded-xl flex items-center justify-center text-2xl overflow-hidden">
              {item.product.imageUrl ? <img src={item.product.imageUrl} alt="" className="w-full h-full object-cover" /> : item.product.image}
            </div>
            <div className="flex-1">
              <h4 className="font-bold text-gray-800 text-xs">{item.product.name}</h4>
              <p className="text-[10px] text-gray-400">{item.product.weightOrSize}</p>
              <p className="font-extrabold text-green-600 text-xs mt-0.5">₹{item.product.discountPrice || item.product.price}</p>
            </div>
            <div className="flex items-center gap-2 bg-gray-50 p-1 rounded-xl border border-gray-200">
              <button onClick={() => updateCartQty(item.product.id, -1)} className="p-1 rounded text-gray-600"><Minus size={12} /></button>
              <span className="font-bold text-xs w-4 text-center">{item.qty}</span>
              <button onClick={() => updateCartQty(item.product.id, 1)} className="p-1 rounded text-green-600"><Plus size={12} /></button>
            </div>
          </div>
        ))}

        <div className="bg-white p-4 rounded-2xl shadow-sm space-y-2 border border-gray-100">
          <h3 className="font-bold text-gray-800 text-xs mb-1">Bill Summary</h3>
          <div className="flex justify-between text-xs text-gray-600">
            <span>Item Total</span>
            <span>₹{itemTotal}</span>
          </div>
          <div className="flex justify-between text-xs text-gray-600">
            <span>Fixed Delivery Charge</span>
            <span className="text-green-600 font-bold">+₹{DELIVERY_CHARGE}</span>
          </div>
          <div className="border-t border-gray-100 pt-2 flex justify-between font-black text-gray-800 text-xs">
            <span>To Pay (COD Only)</span>
            <span className="text-green-600">₹{totalAmount}</span>
          </div>
        </div>

        {/* Delivery Address Card with Change Button */}
        <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 space-y-2">
           <div className="flex justify-between items-center">
             <h3 className="font-bold text-gray-800 text-xs flex items-center gap-1"><MapPin size={12} className="text-green-600"/> Delivery Address</h3>
             <button onClick={() => setIsChangingAddress(!isChangingAddress)} className="text-green-600 text-xs font-bold flex items-center gap-1">
               <Edit3 size={12} /> {isChangingAddress ? 'Cancel' : 'Change Address'}
             </button>
           </div>
           
           {!isChangingAddress ? (
             <div>
               <p className="text-xs font-bold text-gray-700">{userProfile?.name} • {userProfile?.phone}</p>
               <p className="text-xs text-gray-500 mt-0.5">{userProfile?.address}</p>
             </div>
           ) : (
             <form onSubmit={handleUpdateAddress} className="space-y-2 pt-1">
               <textarea 
                 value={newAddressInput} 
                 onChange={e => setNewAddressInput(e.target.value)} 
                 placeholder="Enter new delivery address / landmark..." 
                 className="w-full bg-gray-50 border border-gray-200 rounded-xl p-2.5 text-xs outline-none h-16"
                 required
               />
               <button type="submit" className="w-full bg-green-600 text-white font-bold py-2 rounded-xl text-xs">Save Address</button>
             </form>
           )}
        </div>
      </div>

      <div className="p-4 bg-white border-t border-gray-100">
        <button 
          disabled={isCheckingOut}
          onClick={placeOrder}
          className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 rounded-2xl shadow-lg shadow-green-200 flex items-center justify-center gap-2 active:scale-95 transition-all text-xs"
        >
          {isCheckingOut ? "Placing Order..." : `Confirm COD Order • ₹{totalAmount}`}
        </button>
      </div>
    </div>
  );
}

function OrderHistory({ orders }) {
  if (orders.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center p-6 space-y-3">
        <Package size={54} className="text-gray-300" />
        <h2 className="text-lg font-bold text-gray-700">No Orders Yet</h2>
        <p className="text-xs text-gray-400">Your order history will appear here.</p>
      </div>
    );
  }

  const getStatusColor = (status) => {
    switch(status) {
      case 'Pending': return 'bg-yellow-100 text-yellow-700';
      case 'Accepted': return 'bg-blue-100 text-blue-700';
      case 'Packed': return 'bg-purple-100 text-purple-700';
      case 'Out for Delivery': return 'bg-orange-100 text-orange-700';
      case 'Delivered': return 'bg-green-100 text-green-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="p-4 space-y-3">
      <h2 className="text-lg font-bold text-gray-800 mb-2">My Orders</h2>
      {orders.sort((a,b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0)).map(order => (
        <div key={order.id} className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 space-y-2.5">
          <div className="flex justify-between items-center">
            <span className="text-[10px] text-gray-400 font-bold uppercase">ID: #{order.id}</span>
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${getStatusColor(order.status)}`}>
              {order.status}
            </span>
          </div>
          <div className="space-y-1">
            {order.items.map((item, i) => (
              <p key={i} className="text-xs text-gray-700">{item.qty}x {item.product.name}</p>
            ))}
          </div>
          <div className="border-t border-gray-50 pt-2 flex justify-between items-center text-xs">
            <span className="text-gray-400">{order.paymentMethod}</span>
            <span className="font-extrabold text-gray-800">₹{order.totalAmount}</span>
          </div>
        </div>
      ))}
    </div>
  );
}

function NotificationScreen({ notifications }) {
  if (notifications.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center p-6 space-y-3">
        <Bell size={54} className="text-gray-300" />
        <h2 className="text-lg font-bold text-gray-700">No Notifications</h2>
        <p className="text-xs text-gray-400">Order updates and daily reminders will appear here.</p>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-3">
      <h2 className="text-lg font-bold text-gray-800 mb-2">Notifications & SMS Alerts</h2>
      {notifications.map(n => (
        <div key={n.id} className="bg-white p-3.5 rounded-2xl shadow-sm border border-gray-100 space-y-1">
          <div className="flex justify-between items-center">
            <h4 className="font-bold text-xs text-green-700 flex items-center gap-1"><MessageSquare size={12}/> {n.title}</h4>
            <span className="text-[10px] text-gray-400">{n.time}</span>
          </div>
          <p className="text-xs text-gray-600 leading-relaxed">{n.message}</p>
        </div>
      ))}
    </div>
  );
}

function ProfileScreen({ userProfile, user, showToast, onLogout }) {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({ name: '', phone: '', address: '', pincode: '' });

  useEffect(() => {
    if (userProfile) setFormData(userProfile);
  }, [userProfile]);

  const saveProfile = () => {
    showToast("Profile Updated Successfully!");
    setIsEditing(false);
  };

  return (
    <div className="p-4 space-y-4 bg-gray-50 h-full">
      <div className="bg-white p-4 rounded-2xl shadow-sm flex items-center gap-3">
        <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center text-green-700 font-black text-lg">
          {formData.name?.charAt(0) || 'U'}
        </div>
        <div>
          <h2 className="font-bold text-gray-800 text-xs">{formData.name || 'User'}</h2>
          <p className="text-[10px] text-gray-400">{user.username || 'Girajsar User'}</p>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm p-4 space-y-3 border border-gray-100">
        <div className="flex justify-between items-center border-b border-gray-100 pb-2">
          <h3 className="font-bold text-gray-800 text-xs">Delivery Details</h3>
          <button onClick={() => setIsEditing(!isEditing)} className="text-green-600 text-xs font-bold">
            {isEditing ? 'Cancel' : 'Edit'}
          </button>
        </div>

        {isEditing ? (
          <div className="space-y-2.5 pt-1">
            <input type="text" placeholder="Full Name" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full bg-gray-50 border border-gray-200 rounded-xl p-2.5 text-xs outline-none" />
            <input type="tel" placeholder="Phone Number" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} className="w-full bg-gray-50 border border-gray-200 rounded-xl p-2.5 text-xs outline-none" />
            <textarea placeholder="Address & Landmark" value={formData.address} onChange={e => setFormData({...formData, address: e.target.value})} className="w-full bg-gray-50 border border-gray-200 rounded-xl p-2.5 text-xs outline-none h-20" />
            <button onClick={saveProfile} className="w-full bg-green-600 text-white font-bold py-2.5 rounded-xl text-xs">Save Profile</button>
          </div>
        ) : (
          <div className="space-y-1">
             <p className="text-xs text-gray-700 font-bold">📞 {formData.phone || 'No phone added'}</p>
             <p className="text-xs text-gray-500 leading-relaxed">📍 {formData.address || 'No address added'}</p>
          </div>
        )}
      </div>

      <div className="bg-white rounded-2xl shadow-sm overflow-hidden border border-gray-100">
        <button onClick={onLogout} className="w-full flex items-center justify-between p-3.5 text-red-600 hover:bg-red-50 transition-colors">
          <span className="font-bold text-xs flex items-center gap-2"><LogOut size={16}/> Logout</span>
        </button>
      </div>
    </div>
  );
}

// ================= ADMIN PANEL =================
function AdminPanel({ products, setProducts, orders, setOrders, showToast, addNotification, onLogout }) {
  const [activeTab, setActiveTab] = useState('orders');
  const [isAddingProduct, setIsAddingProduct] = useState(false);
  const [newProd, setNewProd] = useState({
    name: '', category: 'Fruits & Veggies', brand: 'Brand', price: '', discountPrice: '', weightOrSize: '1 kg', stock: '50', image: '📦', imageUrl: ''
  });

  const totalRevenue = orders.filter(o => o.status === 'Delivered').reduce((sum, o) => sum + o.totalAmount, 0);

  const handleAddProductSubmit = (e) => {
    e.preventDefault();
    const stockVal = Number(newProd.stock);
    const priceVal = Number(newProd.price);
    const discountVal = newProd.discountPrice ? Number(newProd.discountPrice) : priceVal;

    const newProductObj = {
      id: 'p_' + Date.now(),
      name: newProd.name.trim(),
      category: newProd.category,
      brand: newProd.brand.trim() || 'Brand',
      price: priceVal,
      discountPrice: discountVal,
      weightOrSize: newProd.weightOrSize.trim() || '1 kg',
      stock: stockVal,
      inStock: stockVal > 0,
      image: newProd.image.trim() || '📦',
      imageUrl: newProd.imageUrl.trim() || ''
    };

    setProducts(prev => [newProductObj, ...prev]);
    showToast("Product Added Successfully! 🚀");
    setIsAddingProduct(false);
    setNewProd({ name: '', category: 'Fruits & Veggies', brand: 'Brand', price: '', discountPrice: '', weightOrSize: '1 kg', stock: '50', image: '📦', imageUrl: '' });
  };

  const deleteProduct = (id) => {
    setProducts(prev => prev.filter(p => p.id !== id));
    showToast("Product deleted.");
  };

  return (
    <div className="flex flex-col h-full bg-gray-100">
      <div className="bg-gray-900 text-white p-4 flex justify-between items-center shadow-md z-10">
        <div>
          <h1 className="font-black text-sm text-green-400">GG ADMIN PANEL (Sahil)</h1>
          <p className="text-[10px] text-gray-400">Orders & Catalog Management</p>
        </div>
        <button onClick={onLogout} className="bg-gray-800 p-2 rounded-xl text-red-400">
          <LogOut size={16} />
        </button>
      </div>

      <div className="flex bg-white shadow-sm border-b border-gray-200 z-10">
        <button onClick={() => setActiveTab('orders')} className={`flex-1 py-3 text-xs font-bold ${activeTab === 'orders' ? 'text-green-600 border-b-2 border-green-600' : 'text-gray-500'}`}>Orders ({orders.length})</button>
        <button onClick={() => setActiveTab('dashboard')} className={`flex-1 py-3 text-xs font-bold ${activeTab === 'dashboard' ? 'text-green-600 border-b-2 border-green-600' : 'text-gray-500'}`}>Stats</button>
        <button onClick={() => setActiveTab('products')} className={`flex-1 py-3 text-xs font-bold ${activeTab === 'products' ? 'text-green-600 border-b-2 border-green-600' : 'text-gray-500'}`}>Catalog ({products.length})</button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {activeTab === 'orders' && (
          <div className="space-y-3">
            {orders.sort((a,b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0)).map(order => (
              <AdminOrderCard key={order.id} order={order} showToast={showToast} addNotification={addNotification} setOrders={setOrders} />
            ))}
            {orders.length === 0 && <p className="text-center text-xs text-gray-400 py-10">No customer orders received yet.</p>}
          </div>
        )}

        {activeTab === 'dashboard' && (
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-white p-4 rounded-2xl shadow-sm border-l-4 border-green-500">
                <p className="text-[10px] text-gray-400 font-bold uppercase">Total Revenue</p>
                <h3 className="text-xl font-black text-gray-800 mt-1">₹{totalRevenue}</h3>
              </div>
              <div className="bg-white p-4 rounded-2xl shadow-sm border-l-4 border-blue-500">
                <p className="text-[10px] text-gray-400 font-bold uppercase">Total Orders</p>
                <h3 className="text-xl font-black text-gray-800 mt-1">{orders.length}</h3>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'products' && (
          <div className="space-y-3">
            <button 
              onClick={() => setIsAddingProduct(!isAddingProduct)}
              className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2.5 rounded-xl text-xs flex items-center justify-center gap-2 shadow-sm"
            >
              <PlusCircle size={16} /> {isAddingProduct ? "Cancel" : "Add New Product"}
            </button>

            {isAddingProduct && (
              <form onSubmit={handleAddProductSubmit} className="bg-white p-4 rounded-2xl shadow-sm space-y-3 border border-gray-200">
                <h3 className="font-bold text-xs text-gray-800">Add Product</h3>
                <input type="text" placeholder="Name (e.g. Tomatoes)" value={newProd.name} onChange={e => setNewProd({...newProd, name: e.target.value})} className="w-full bg-gray-50 border border-gray-200 rounded-xl p-2.5 text-xs outline-none" required />
                <select value={newProd.category} onChange={e => setNewProd({...newProd, category: e.target.value})} className="w-full bg-gray-50 border border-gray-200 rounded-xl p-2.5 text-xs outline-none">
                  {SEED_CATEGORIES.filter(c => c !== 'All').map(c => <option key={c} value={c}>{c}</option>)}
                </select>
                <div className="grid grid-cols-2 gap-2">
                  <input type="number" placeholder="MRP Price (₹)" value={newProd.price} onChange={e => setNewProd({...newProd, price: e.target.value})} className="bg-gray-50 border border-gray-200 rounded-xl p-2.5 text-xs outline-none" required />
                  <input type="number" placeholder="Selling Price (₹)" value={newProd.discountPrice} onChange={e => setNewProd({...newProd, discountPrice: e.target.value})} className="bg-gray-50 border border-gray-200 rounded-xl p-2.5 text-xs outline-none" />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <input type="text" placeholder="Weight (e.g. 1 kg)" value={newProd.weightOrSize} onChange={e => setNewProd({...newProd, weightOrSize: e.target.value})} className="bg-gray-50 border border-gray-200 rounded-xl p-2.5 text-xs outline-none" required />
                  <input type="number" placeholder="Stock" value={newProd.stock} onChange={e => setNewProd({...newProd, stock: e.target.value})} className="bg-gray-50 border border-gray-200 rounded-xl p-2.5 text-xs outline-none" required />
                </div>
                <input type="url" placeholder="Image URL (Unsplash)" value={newProd.imageUrl} onChange={e => setNewProd({...newProd, imageUrl: e.target.value})} className="w-full bg-gray-50 border border-gray-200 rounded-xl p-2.5 text-xs outline-none" />
                <button type="submit" className="w-full bg-gray-900 text-white font-bold py-2.5 rounded-xl text-xs">Save Product</button>
              </form>
            )}

            <div className="space-y-2">
               {products.map(p => (
                 <div key={p.id} className="bg-white p-3 rounded-xl shadow-sm flex items-center justify-between border border-gray-100">
                   <div className="flex items-center gap-3">
                     <div className="w-9 h-9 bg-gray-50 rounded-lg flex items-center justify-center text-xl overflow-hidden">
                       {p.imageUrl ? <img src={p.imageUrl} alt="" className="w-full h-full object-cover"/> : p.image}
                     </div>
                     <div>
                       <p className="font-bold text-xs text-gray-800">{p.name}</p>
                       <p className="text-[10px] text-gray-400">₹{p.discountPrice || p.price} • Stock: {p.stock}</p>
                     </div>
                   </div>
                   <button onClick={() => deleteProduct(p.id)} className="text-red-500 p-1.5 hover:bg-red-50 rounded-lg">
                     <Trash2 size={16} />
                   </button>
                 </div>
               ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function AdminOrderCard({ order, showToast, addNotification, setOrders }) {
  const updateStatus = (newStatus) => {
    setOrders(prev => prev.map(o => o.id === order.id ? { ...o, status: newStatus } : o));
    
    if (newStatus === 'Accepted') {
      addNotification("Order Accepted 👍", `Aapka order #${order.id} accept kar liya gaya hai aur pack ho raha hai.`);
    } else if (newStatus === 'Out for Delivery') {
      addNotification("Out for Delivery 🚀", `Aapka order #${order.id} delivery ke liye nikal chuka hai!`);
    } else if (newStatus === 'Delivered') {
      addNotification("Order Delivered ✅", `Aapka order #${order.id} successfully deliver ho gaya hai. Thank you!`);
    }

    showToast(`Status updated to ${newStatus}`);
  };

  const statuses = ['Pending', 'Accepted', 'Packed', 'Out for Delivery', 'Delivered', 'Cancelled'];

  return (
    <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-200 space-y-2.5">
      <div className="flex justify-between items-start border-b border-gray-100 pb-2">
        <div>
          <h3 className="font-bold text-gray-800 text-xs">Order #{order.id}</h3>
          <p className="text-[10px] text-gray-400">{order.customerName} • 📞 {order.mobileNumber}</p>
        </div>
        <select 
          value={order.status}
          onChange={(e) => updateStatus(e.target.value)}
          className="bg-gray-50 border border-gray-300 text-gray-900 text-[10px] rounded-lg p-1.5 font-bold outline-none"
        >
          {statuses.map(s => <option key={s} value={s}>{s}</option>)}
        </select>
      </div>

      <p className="text-xs text-gray-600">📍 {order.address}</p>

      <div className="bg-gray-50 p-2 rounded-xl space-y-1">
        {order.items.map((item, idx) => (
          <div key={idx} className="flex justify-between text-xs text-gray-700">
            <span>{item.qty}x {item.product.name}</span>
            <span className="font-bold">₹{(item.product.discountPrice || item.product.price) * item.qty}</span>
          </div>
        ))}
      </div>

      <div className="flex justify-between items-center border-t border-gray-100 pt-2 text-xs">
        <span className="text-gray-400">Delivery: ₹{order.deliveryCharge}</span>
        <span className="font-black text-gray-800">Total: ₹{order.totalAmount}</span>
      </div>
    </div>
  );
}